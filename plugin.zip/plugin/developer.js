var config = {
    apiKey: "AIzaSyAfjj0Zgd5nZERPXswVyi74xJ5ndtP8s_k",
    authDomain: "drsplugin.firebaseapp.com",
    databaseURL: "https://drsplugin.firebaseio.com",
    projectId: "drsplugin",
    storageBucket: "drsplugin.appspot.com",
    messagingSenderId: "767238286845"
  };
  firebase.initializeApp(config);
var review_count=0;
function database_retriever()
{
    var firebaseRef = firebase.database().ref();
    firebaseRef.once("value").then(function(snapshot){
    num = snapshot.child("count").val();
    if(review_count<num)
    {
        var i=0;
        for(i=0;i<num;i++)
        {

            var txt1=snapshot.child("issue-"+(i+1)).child("action").val();
            var txt2=snapshot.child("issue-"+(i+1)).child("error").val();
            var txt3=snapshot.child("issue-"+(i+1)).child("suggestion").val();
            var class_num=categorize(txt1,txt2,txt3);
            if(class_num==-1){
                class_num = i%4+1;
            }
            if(class_num==1)
            {
              var d=document.createElement("div");
              d.setAttribute("class","dropdown");  
              var x=document.createElement("button");
              x.setAttribute("class", "btn btn-danger dropdown-toggle");
              x.setAttribute("data-toggle","dropdown");
              x.setAttribute("id","issue_button");
              x.setAttribute("type","button");
              x.innerHTML="issue-"+(i+1);
              d.appendChild(x);
              var y=document.createElement("div");
              y.setAttribute("class","dropdown-menu");
              var t1=document.createElement('p');
              t1.innerHTML=txt1;
              var t2=document.createElement('p');
              t2.innerHTML=txt2;
              var t3=document.createElement('p');
              t3.innerHTML=txt3;
              y.appendChild(t1);
              y.appendChild(t2);
              y.appendChild(t3);
              x.appendChild(y);
              loc=document.getElementById("col-1");
              loc.appendChild(d); 
            }
            if(class_num==2)
            {
               var d=document.createElement("div");
              d.setAttribute("class","dropdown");  
              var x=document.createElement("button");
              x.setAttribute("class", "btn btn-warning dropdown-toggle");
              x.setAttribute("data-toggle","dropdown");
              x.setAttribute("id","issue_button");
              x.setAttribute("type","button");
              x.innerHTML="issue-"+(i+1);
              d.appendChild(x);
              var y=document.createElement("div");
              y.setAttribute("class","dropdown-menu");
              var t1=document.createElement('p');
              t1.innerHTML=txt1;
              var t2=document.createElement('p');
              t2.innerHTML=txt2;
              var t3=document.createElement('p');
              t3.innerHTML=txt3;
              y.appendChild(t1);
              y.appendChild(t2);
              y.appendChild(t3);
              x.appendChild(y);
              loc=document.getElementById("col-2");
              loc.appendChild(d);              
            }
            if(class_num==3)
            {
              var d=document.createElement("div");
              d.setAttribute("class","dropdown");  
              var x=document.createElement("button");
              x.setAttribute("class", "btn btn-primary dropdown-toggle");
              x.setAttribute("data-toggle","dropdown");
              x.setAttribute("id","issue_button");
              x.setAttribute("type","button");
              x.innerHTML="issue-"+(i+1);
              d.appendChild(x);
              var y=document.createElement("div");
              y.setAttribute("class","dropdown-menu");
              var t1=document.createElement('p');
              t1.innerHTML=txt1;
              var t2=document.createElement('p');
              t2.innerHTML=txt2;
              var t3=document.createElement('p');
              t3.innerHTML=txt3;
              y.appendChild(t1);
              y.appendChild(t2);
              y.appendChild(t3);
              x.appendChild(y);
              loc=document.getElementById("col-3");
              loc.appendChild(d); 
            }
            if(class_num==4)
            {
                var d=document.createElement("div");
              d.setAttribute("class","dropdown");  
              var x=document.createElement("button");
              x.setAttribute("class", "btn btn-success dropdown-toggle");
              x.setAttribute("data-toggle","dropdown");
              x.setAttribute("id","issue_button");
              x.setAttribute("type","button");
              x.innerHTML="issue-"+(i+1);
              d.appendChild(x);
              var y=document.createElement("div");
              y.setAttribute("class","dropdown-menu");
              var t1=document.createElement('p');
              t1.innerHTML=txt1;
              var t2=document.createElement('p');
              t2.innerHTML=txt2;
              var t3=document.createElement('p');
              t3.innerHTML=txt3;
              y.appendChild(t1);
              y.appendChild(t2);
              y.appendChild(t3);
              x.appendChild(y);
              loc=document.getElementById("col-4");
              loc.appendChild(d);  
            }
        }
    review_count=i;    
    }
    else
    {
        alert("All Reviews Are Loaded");
    }
        });
}    
document.getElementById("Get-Reviews").addEventListener("click",database_retriever);
function categorize(text1,text2,text3)
{
    var bug_report=["bug", "fix", "problem", "issue", "defect", "crash", "solve" ];

    var feature_request=["add","please","could","would","hope","improve","miss","need","prefer"
                                ,"request","should","suggest","want","wish"];

    var user_experience=["help", "support", "assist", "when", "situation"];
    var rating=["Great", "good", "nice", "very", "cool", "love", "hate", "bad", "worst"];
    var review=text1+" "+text2+" "+text3;
    review=review.replace(/[^a-zA-Z0-9 ]/g," ").toLowerCase();
    var review_words=[];
    review_words=review.split(" ");
    var common_bug_report =$.grep(review_words,function(element)
    {
        return $.inArray(element,bug_report)!==-1;
    });
    var common_feature_request =$.grep(review_words,function(element)
    {
        return $.inArray(element,feature_request)!==-1;
    });
    var common_user_experience =$.grep(review_words,function(element)
    {
        return $.inArray(element,user_experience)!==-1;
    });
     var common_rating =$.grep(review_words,function(element)
    {
        return $.inArray(element,rating)!==-1;
    });
    var bug_len=common_bug_report.length;
    var feature_len=common_feature_request.length;
    var experience_len=common_user_experience.length;
    var rating_len=common_rating.length;
    if(bug_len==0&&feature_len==0&&experience_len==0&&rating_len==0)
    {
        //alert("Hi");
        return -1;
    }
    else
    {
        var len_array = [bug_len,feature_len,experience_len,rating_len];
        var i = len_array.indexOf(Math.max(...len_array));
        return i+1;
    }
}